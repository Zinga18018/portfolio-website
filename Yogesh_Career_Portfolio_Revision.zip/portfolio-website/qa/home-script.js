
(() => {
  const search = document.getElementById('repo-search');
  const entries = [...document.querySelectorAll('.repo-entry')];
  search.addEventListener('input', () => {
    const query = search.value.trim().toLowerCase();
    let count = 0;
    entries.forEach(entry => { entry.hidden = !entry.textContent.toLowerCase().includes(query); if (!entry.hidden) count++; });
    document.getElementById('repo-status').textContent = `${count} project${count === 1 ? '' : 's'} shown${count ? '.' : '. Try another search.'}`;
  });
  const motionQuery = matchMedia('(prefers-reduced-motion: reduce)');
  let reduce = motionQuery.matches;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  document.getElementById('year').textContent = new Date().getFullYear();

  // reveal on scroll
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { rootMargin: '0px 0px -8% 0px' });
  document.querySelectorAll('.r').forEach(el => io.observe(el));
  // Enable decorative reveals only after the observer is ready. Content stays
  // visible if this script fails or JavaScript is disabled.
  document.documentElement.classList.add('js');

  // live repository count, same source as the GitHub profile
  fetch('https://api.github.com/users/Zinga18018').then(r => (r.ok ? r.json() : null)).then(u => {
    if (u && u.public_repos) document.querySelectorAll('.repo-count').forEach(el => (el.textContent = u.public_repos));
  }).catch(() => {});

  // stacked cards shrink and dim as the next one lands; timeline line draws with scroll
  const items = [...document.querySelectorAll('.stack-item')];
  const sticky = { matches: false }; // Long evidence cards remain readable without overlap.
  const tl = document.getElementById('timeline');
  const navigation = document.querySelector('.nav');
  const sectionLinks = [...document.querySelectorAll('.links a[href^="#"]')];
  const sectionTargets = sectionLinks.map(link => document.querySelector(link.getAttribute('href')));
  const GAP = 36, STEP = 24;
  let queued = false;
  function onScroll() {
    queued = false;
    // Keep the same section links available on every screen, with a current marker.
    const marker = navigation.getBoundingClientRect().height + 64;
    let currentSection = -1;
    sectionTargets.forEach((target, index) => {
      if (target && target.getBoundingClientRect().top <= marker) currentSection = index;
    });
    sectionLinks.forEach((link, index) => {
      if (index === currentSection) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
    items.forEach((it, i) => {
      const card = it.firstElementChild, next = items[i + 1];
      let p = 0;
      if (next && sticky.matches) {
        const dist = next.getBoundingClientRect().top - it.getBoundingClientRect().top;
        p = clamp(1 - (dist - STEP) / (it.offsetHeight + GAP - STEP), 0, 1);
      }
      card.style.setProperty('--s', 1 - p * 0.06);
      card.style.setProperty('--b', 1 - p * 0.45);
    });
    const r = tl.getBoundingClientRect();
    tl.style.setProperty('--p', clamp((innerHeight * 0.7 - r.top) / r.height, 0, 1));
  }
  const queue = () => { if (!queued) { queued = true; requestAnimationFrame(onScroll); } };
  addEventListener('scroll', queue, { passive: true });
  addEventListener('resize', queue);
  onScroll();

  // tilt card with a light that follows the pointer
  const card = document.getElementById('now');
  if (matchMedia('(hover: hover)').matches) {
    card.addEventListener('pointermove', e => {
      if (reduce) return;
      const b = card.getBoundingClientRect(), x = (e.clientX - b.left) / b.width, y = (e.clientY - b.top) / b.height;
      card.style.setProperty('--rx', (0.5 - y) * 14 + 'deg');
      card.style.setProperty('--ry', (x - 0.5) * 14 + 'deg');
      card.style.setProperty('--mx', x * 100 + '%');
      card.style.setProperty('--my', y * 100 + '%');
    });
    card.addEventListener('pointerleave', () => { card.style.setProperty('--rx', '0deg'); card.style.setProperty('--ry', '0deg'); });
  }

  // copy email
  document.querySelectorAll('[data-copy]').forEach(b => b.addEventListener('click', () => {
    if (!navigator.clipboard) { b.textContent = 'SELECT EMAIL'; return; }
    navigator.clipboard.writeText(b.dataset.copy).then(() => {
      b.textContent = 'COPIED';
      setTimeout(() => (b.textContent = 'COPY'), 1600);
    }).catch(() => { b.textContent = 'SELECT EMAIL'; });
  }));

  // The atlas is readable and selectable without JavaScript. Its only scripted
  // behavior is decorative motion, paused when hidden, off-screen, or touched.
  const hero = document.querySelector('.hero');
  const atlas = document.querySelector('.atlas');
  const motionButton = document.getElementById('atlas-motion');
  let atlasVisible = false;
  let motionPaused = false;

  function syncAtlasMotion() {
    const playing = !reduce && atlasVisible && !document.hidden && !motionPaused;
    atlas.classList.toggle('is-playing', playing);
    motionButton.hidden = reduce;
    motionButton.textContent = motionPaused ? 'Play motion' : 'Pause motion';
  }

  new IntersectionObserver(([entry]) => {
    atlasVisible = entry.isIntersecting;
    syncAtlasMotion();
  }, { threshold: .02 }).observe(atlas);
  document.addEventListener('visibilitychange', syncAtlasMotion);
  atlas.querySelectorAll('input[name="atlas-locus"]').forEach(input => {
    input.addEventListener('change', () => {
      motionPaused = true;
      syncAtlasMotion();
    });
  });
  motionButton.addEventListener('click', () => {
    motionPaused = !motionPaused;
    syncAtlasMotion();
  });
  motionQuery.addEventListener('change', event => {
    reduce = event.matches;
    if (reduce) {
      card.style.setProperty('--rx', '0deg');
      card.style.setProperty('--ry', '0deg');
    }
    syncAtlasMotion();
  });
})();
