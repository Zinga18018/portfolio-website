from lxml import html
from pathlib import Path
from urllib.parse import urlsplit
import json,zipfile,hashlib
r=Path(__file__).resolve().parents[1];out=r/'out';results=[]
for f in ['index.html','career-summary.html','evidence/driftlab-10000.html']:
 d=html.fromstring((out/f).read_text());ids=d.xpath('//@id');bad=[h for h in d.xpath('//a/@href') if h.startswith('#') and h[1:] not in ids];missing=[]
 for attr in d.xpath('//a/@href|//img/@src|//video/@poster|//source/@src'):
  if attr.startswith('/') and not attr.startswith('//'):
   u=urlsplit(attr);dest=out/u.path.lstrip('/');dest=dest/'index.html' if dest.is_dir() else dest
   if not dest.exists():missing.append(attr)
 results.append(dict(file=f,duplicate_ids=[i for i in set(ids) if ids.count(i)>1],broken_fragments=bad,missing_local_assets=missing,h1_count=len(d.xpath('//h1'))))
 if f=='index.html':
  scripts=d.xpath('//script/text()');(r/'qa/home-script.js').write_text('\n'.join(scripts));results[-1]['project_order']=d.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," stack-item ")]//h3/text()');results[-1]['archive_collapsed']=not bool(d.xpath('//details[@class="archive-search"]/@open'))
  assert len(results[-1]['project_order'])==7
  assert results[-1]['archive_collapsed']
assert all(not x['duplicate_ids'] and not x['broken_fragments'] and not x['missing_local_assets'] and x['h1_count']==1 for x in results)
with zipfile.ZipFile(out/'evidence/driftlab-10000-evidence.zip') as z:
 trials=z.read('driftlab-10000/outputs/no_drift_10000/trials.jsonl');n=len(trials.splitlines());assert n==10000
results.append({'evidence_records':n,'trials_sha256':hashlib.sha256(trials).hexdigest()})
(r/'qa/static-checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
